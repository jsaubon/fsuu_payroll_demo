export default function AppReducer(state, action) {
    switch (action.type) {
        default:
            return state;
    }
}
