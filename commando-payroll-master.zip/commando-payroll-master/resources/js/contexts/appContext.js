import { createContext } from "react";

const AppContext = createContext({
    app: ""
});

export default AppContext;
