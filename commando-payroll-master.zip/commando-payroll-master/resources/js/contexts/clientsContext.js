import { createContext } from "react";

const ClientsContext = createContext({
    clients: []
});

export default ClientsContext;
